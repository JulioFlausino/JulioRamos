<?php
namespace app\models;

use yii\db\ActiveRecord;
use yii\db\Query;
use Yii;

class Cadastro
{
    public function adicionar($dados, $score)
    {

        try {
            Yii::$app->db->createCommand()
                ->insert('cadastro', [
                    'nmcadastro' => $dados['nome'],
                    'email' => $dados['email'],
                    'dtnascimento' => Utils::formatDateToDBb($dados['dtnascimento']),
                    'telefone' => Utils::formatTelToDb2($dados['telefone']),
                    'id_unidade' => $dados['id'],
                    'score' => $score,
                ])->execute();

            return true;

        } catch (Exception $e) {
            echo 'Exceção capturada: ', $e->getMessage(), "\n";
        }

    }

    public function calcularScore($dados)
    {
        $score = 10;
        if($dados['unidade'] != 'São Paulo') {
            $scoreRegiao = Utils::getRegiao($dados['regiao']);
            $score = $score - $scoreRegiao;
        }
        $idade = $this->getIdade($dados['dtnascimento']);

        $score = $score - $idade;

        return $score;
    }

    function multiexplode ($delimiters) {

       $dt = explode('/', $delimiters);
       return $dt;
    }

    function getIdade($dtNascimento){

        $ano = '2016';
        $mes = '11';
        $dia = '01';
        $mktimeDtDefault = Utils::returnTime($ano, $mes, $dia);
        $dateAConfirm = $this->multiexplode($dtNascimento);
        list($days, $month, $year) = $dateAConfirm;
        $mktimeDtAConfirmar = Utils::returnTime($year, $month, $days);
        $dtIdade = $mktimeDtDefault - $mktimeDtAConfirmar;
        $idade = floor((((($mktimeDtDefault - $mktimeDtAConfirmar) / 60) / 60) / 24) / 365.25);

        if($idade >=100 || $idade < 18){
          return 5;

        }elseif($idade >= 40 && $idade <=99){
            return 3;
        }else{
            return 0;
        }

    }

}