<?php
namespace app\models;

use yii\db\ActiveRecord;
use yii\db\Query;
use Yii;

class Regiao
{
    public function getRegiao()
    {
        $query = new Query();
        $query->select('*')
            ->from('regiao');
        $rows = $query->all();

        return $rows;

    }

}