<?php
namespace app\models;

use yii\db\ActiveRecord;
use yii\db\Query;
use Yii;

class Unidade
{
    public function getUnidadeByIdRegiao($id)
    {
        if(empty($id)){
            return false;
        }
        $query = new Query();
        $query->select('*')
            ->from('unidade')
            ->where("id_regiao = {$id}");
        $rows = $query->all();

        return $rows;

    }

}