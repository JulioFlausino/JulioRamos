<?php
namespace app\models;

/**

* Classe desenvolvida para auxiliar nas valida��es de formul�rio
*/
class Validacao
{
   /**
   * Configura��o da valida��o, podendo conter as seguintes chaves:
   *
   * label => Nome a ser utilizado no campo para o erro da mensagem
   * value => O valor contido no campo
   * rules => Array contendo as regras de valida��o
   * messages => Mensagens de valida��o para o campo, caso nenhuma mensagem seja utilizada, 
   * utilizara as mensages da vari�vel $defaultMessages
   */
   protected $_config;
   
   /**
   * Erros gerados pela valida��o
   */
   protected $_erros;
   
   /**
   * Status atual da valida��o, indica se os dados est�o v�lidos ou n�o
   */
   protected $_valido;
   
   
   /**
   * Valor atual do la�o de repeti��o da valida��o
   */ 
   protected $_value;
   
   /**
   * Id atual do la�o de repeti��o
   */
   protected $_id;
   
   /**
   * Label atual do la�o de repeti��o
   */
   protected $_label;
   
   /**
   * Regra atual do la�o de repeti��o
   */
   protected $_rule;
   
   /**
   * Mensagens atuais do la�o de repti��o
   */
   protected $_messages;
   
   /**
   * Tag de in�cio para mensagens de erro formatadas
   */ 
   protected $_tagInicio = '<li>';
   
   /**
   * Tag de fim para mensagens de erro formatadas
   */
   protected $_tagFim = '</li>';
   
   /**
   * Mensagens padr�o para cada regra de valida��o
   * � poss�vel utilizar par�metros para substituir valores, sendo que o valor {1} sempre ser� a label atual do la�o de repeti��o
   * e os demais campos, os passados como par�metro para o m�todo addErro
   */
   private $defaultMessages = array(
      'obrigatorio' => 'O campo {1} &eacute; obrigat&oacute;rio.',
      'maxlength' => 'O campo {1} deve conter no m&aacute;ximo {2} caracteres.',
        'menorque' => 'O campo {1} deve ser menor ou igual a {2}.',
      'valorIgual' => 'O campo {1} deve conter valor igual a {2}.',
        'minlength' => 'O campo {1} deve conter no m&iacute;nimo {2} caracteres.',
      'email' => 'O campo {1} deve ser preenchido com um e-mail v&aacute;lido.',
      'telefone' => 'O campo {1} deve ser preenchido com um telefone v&aacute;lido.',
      'arrayComValor' => 'O campo {1} deve conter pelo menos um valor.',
      'uniqueInDb' => 'O {1} j&aacute; existe no banco de dados, por favor, utilize outro.',
      'inArray' => 'O campo {1} deve conter um dos seguintes valores: {2}.',
        'inKeyArray' => 'O campo {1} deve conter um dos seguintes valores: {2}.',
      'arrayKeysIn' => 'O array {1} cont&eacute;m chaves inexistentes.',
        'arrayKeysNotIn' => 'O array {1} cont&eacute;m chaves do outro array.',
      'equalsTo' => 'O campo {1} deve conter um valor igual a {2}.',
      'inteiro' => 'O campo {1} deve conter um n&uacute;mero inteiro.',
      'maiorZero' => 'O campo {1} deve ser maior que 0.',
        'horaMaiorZero' => '{1} deve ser maior que zero.',
      'valor' => 'O campo {1} deve conter um valor.',
      'cep' => 'O campo {1} deve conter um cep v&aacute;lido.',
      'cpf' => 'O campo {1} deve conter um CPF v&aacute;lido.',
        'cnpj' => 'O campo {1} deve conter um CNPJ v&aacute;lido.',
      'data' => 'O campo {1} deve conter uma data v&aacute;lida.',
        'dimensao' => 'As dimens&otilde;es da imagem s&atilde;o inv&aacute;lidas.',
        'dataMaiorQue' => 'O campo {1} deve ser maior ou igual &agrave; data {2}.',
      'hora' => 'O campo {1} deve conter uma hora v&aacute;lida.',
      'permalink' => 'O campo {1} deve conter somente letras e n&uacute;meros.',
      'url' => 'O campo {1} deve ser preenchido com um endere&ccedil;o v&aacute;lido (n&atilde;o esque&ccedil;a do "http://" ou "https://").',
        'prazo' => 'O campo {1} deve ser posterior ou igual o campo {2}',
        'mes' => 'O campo {1} deve conter um m&ecirc;s v&aacute;lido.',
      'existsInDb' => 'O {1} escolhido n&atilde;o existe.',
       'sobrenome' => 'O {1} Deve Conter 2 palavras',
   );
   
   /**
   * Construtor da classe
   */
   public function __construct(array $config)
   {
      $this->_config = $config;
      $this->_erros = array();
      $this->_valido = true;
   }

    /**
     * M�todo respons�vel pela valida��o dos dados
     * @return bool
     */
   public function validar()
   {
      foreach($this->_config as $id => $config){
         $this->_value = $config['value'];
         $this->_id = $id;
         $this->_label = $config['label'];
         $this->_messages = $config['messages'];
         foreach($config['rules'] as $rule){
            if(!isset($this->_erros[$this->_id])){
               if(is_array($rule)){
                  $method = array_shift($rule);
                  $this->_rule = $method;
                  call_user_func_array(array($this, $method), $rule);
               }else{
                  $method = $rule;
                  $this->_rule = $rule;
                  $this->$method();
               }
            }
         }
      }

      return $this->_valido;
   }

    /**
     * Adiciona um erro de valida��o, m�todo privado da classe
     */
   protected function addErro()
   {  
      $this->_valido = false;
      
      if(isset($this->_messages[$this->_rule])){
         $message = $this->_messages[$this->_rule];
      }else{
         $message = $this->defaultMessages[$this->_rule];
      }
      
      $args = func_get_args();
      $parameters = array_merge(array($this->_label), $args);
      
      if(!isset($this->_erros[$this->_id])){
         $this->_erros[$this->_id] = $this->formatMessage($message, $parameters);
      }
   }

    /**
     * Formata as mensagens de erro substituindo suas respectivas chaves com n�mero atual de argumento
     * @param $message
     * @param $parameters
     * @return mixed
     */
   protected function formatMessage($message, $parameters)
   {
      foreach($parameters as $key => $value){
         $message = str_replace('{' . ($key + 1) . '}', $value, $message);
      }
      
      return $message;
   }

    /**
     * Seta a tag para abrir mensagens formatadas
     * @param $tag
     */
   public function setTagInicio($tag)
   {
      $this->_tagInicio = $tag;
   }

    /**
     * Seta a tag para fechar mensagens formatadas
     * @param $tag
     */
   public function setTagFim($tag)
   {
      $this->_tagFim = $tag;
   }

    /**
     * Retorna os erros gerados pela valida��o
     * @param bool|false $formatar
     * @return array|null|string
     */
   public function getErros($formatar = false)
   {
      if(!$formatar){
         return $this->_erros;
      }
      
      $errMessage = null;
      foreach($this->_erros as $erro){
         $errMessage .= "{$this->_tagInicio}{$erro}{$this->_tagFim}";
      }
      
      return $errMessage;
   }

    /**
     * Verifica se o campo n�o � vazio
     */
   protected function obrigatorio()
   {
        $value = !is_array($this->_value) ? trim($this->_value) : 0;
        if(strlen($value) == 0 || $value == '-1'){
            $this->addErro();
        }
   }

    /**
     * Verifica se um campo n�o excede um n�mero m�ximo de caracteres
     * @param $max
     */
   protected function maxlength($max)
   {
      $value = trim(Formata::removeAcento($this->_value));
      if(strlen($value) > $max){
         $this->addErro($max);
      }
   }

    protected function sobrenome($valor)
    {
        $value = explode(" ", $valor);
        $cc = count($value);
        if($cc <= 1){
            $this->addErro($valor);
        }
    }

    /**
     * Verifica se um campo n�o excede
     * @param $max
     */
    protected function menorque($max)
    {
        if($this->_value > $max && $max > 0){
            $this->addErro($max);
        }
    }

   /**
    * Verifica se um campo tem o vlaor igual ao parametro passado
    * @param $valor
    */
   protected function valorIgual($valor)
   {
      $value = intval($this->_value);
      if($value != $valor){
         $this->addErro($valor);
      }
   }

    /**
     * Verifica se um campo tem um n�mero m�nimo de caracteres
     * @param $min
     */
    protected function minlength($min)
    {
        $value = trim($this->_value);
        if(strlen($value) < $min){
         $this->addErro($min);
        }
    }

    /**
     * Verifica se o campo cont�m um endere�o de e-mail v�lido
     */
   protected function email()
   {
      if(!empty($this->_value) && !preg_match("/^[0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\\.[a-z]{2,20}$/", $this->_value)){
         $this->addErro();
      }
   }

    /**
     * Verifica se o campo cont�m um cep v�lido
     */
   protected function cep()
   {
        if(strlen($this->_value) < 10){
            $this->addErro();
        }
      if(!empty($this->_value) && strlen($this->_value) == 10){
         if(!preg_match("/^[0-9]{2}.[0-9]{3}-[0-9]{3}/", $this->_value)){
            $this->addErro();
         }
      }

   }

    /**
     * Verifica se o campo cont�m um cpf v�lido
     */
   protected function cpf()
   {
      if(!empty($this->_value)){
         if(!preg_match("/^([0-9]{3}).([0-9]{3}).([0-9]{3})-([0-9]{2})/", $this->_value)){
            $this->addErro();
         }else{
            $this->_value = str_replace ('.', '', $this->_value);
            $this->_value = str_replace ('-', '', $this->_value);
      
            if(strlen($this->_value) != 11){
               $this->addErro();
            }else{ 
               $INS_cpf=preg_replace("/[^0-9]/","",$this->_value);
               $c=substr($this->_value, 0,9);
               $v=substr($this->_value, 9,2);
               $d=0;
               $val=true;
               for ($i=0;$i<9;$i++){
                  $d+=$c[$i]*(10-$i);
               }
               $d==0 ? $val=false:null;
               $d= (11-($d%11))>9 ? 0:11-($d%11);
               $v[0]!=$d ? $val=false:null; 
               $d *=2;
               for ($i=0;$i<9;$i++){
                  $d+=$c[$i]*(11-$i);
               }
               $d= (11-($d%11))>9 ? 0:11-($d%11);
               $v[1]!=$d ? $val=false:null;
               preg_match("/0{11}|1{11}|2{11}|3{11}|4{11}|5{11}|6{11}|7{11}|8{11}|9{11}/",$INS_cpf) ? $val=false : null;
               if(!$val){
                  $this->addErro();
               }
            }
         }
      }
   }

    /**
     * Verifica se o campo cont�m um cnpj v�lido
     */
    protected function cnpj()
    {
        $cnpj = str_pad(str_replace(array('.','-','/'),'',$this->_value),14,'0',STR_PAD_LEFT);
        if (strlen($cnpj) != 14){
            $this->addErro();
        }else{
            for($t = 12; $t < 14; $t++){
                for($d = 0, $p = $t - 7, $c = 0; $c < $t; $c++){
                    $d += $cnpj{$c} * $p;
                    $p  = ($p < 3) ? 9 : --$p;
                }
                $d = ((10 * $d) % 11) % 10;
                if($cnpj{$c} != $d){
                    $this->addErro();
                }
            }
        }
    }

    /**
     * Verifica se o campo cont�m uma data v�lida
     */
   protected function data()
   {
        if(!empty($this->_value)){
            $this->_value = str_replace('-', '/', $this->_value);

            if(!preg_match("/^[0-9]{2}\/[0-9]{2}\/[0-9]{4}$/", $this->_value)){
                $this->addErro();
            }else{
                list($dia, $mes, $ano) = explode('/', $this->_value);

                if(!checkdate($mes, $dia, $ano)){
                    $this->addErro();
                }
            }
        }
   }

   /**
   * Verifica se uma data � menor que a outra
   * @param date $data
   */
   protected function dataMaiorQue($data)
   {
      $value = $this->_value;
      $dataIni = explode('/', $value);
      $dataFim = explode('/', $data);
      $timestampIni = mktime(0, 0, 0, $dataIni[1], $dataIni[0], $dataIni[2]);
      $timestampFim = mktime(0, 0, 0, $dataFim[1], $dataFim[0], $dataFim[2]);
      if($timestampIni < $timestampFim){
         $this->addErro($data);
      }
   }

    /**
     * Verifica se o campo cont�m uma hora v�lida
     */
   protected function hora()
   {
        if(!empty($this->_value)) {
            if (!preg_match('/[0-9]{2}:[0-9]{2}/', $this->_value)) {
                $this->addErro();
            } else {
                list($horas, $minutos, $segundos) = explode(':', $this->_value);
                if ($horas > 23 || $minutos > 59 || $segundos > 59) {
                    $this->addErro();
                }
            }
        }
   }

    /**
     * Verifica se o campo cont�m uma hora maior que zero
     */
    protected function horaMaiorZero()
    {
        if(!empty($this->_value)) {
            if (!preg_match('/[0-9]{2}:[0-9]{2}/', $this->_value)){
                $this->addErro();
            }else{
                list($horas, $minutos, $segundos) = explode(':', $this->_value);
                if ($horas == 0 && $minutos == 0) {
                    $this->addErro();
                }
            }
        }
    }

    /**
     * Verifica se o campo est� com formato de hora
     */
    protected function formatoHora()
    {
        if(!empty($this->_value)) {
            if (!preg_match('/[0-9]{2}:[0-9]{2}/', $this->_value)) {
                $this->addErro();
            }
        }
    }

    /**
     * Verifica se um campo cont�m um n�mero de telefone v�lido
     */
    protected function telefone()
    {
        if(!empty($this->_value)){
            $this->_value= trim(str_replace('/', '', str_replace(' ', '', str_replace('-', '', str_replace(')', '', str_replace('(', '', $this->_value))))));

            if(strlen($this->_value) == 11){
                $eregi = "/^11|12|13|14|15|16|17|18|19|21|22|24|27|29 9(5[0-9]|6[0-9]|7[01234569]|8[0-9]|9[0-9])[0-9]{1}[0-9]-[0-9]{4}$^/";
            }else{
                $eregi = strlen($this->_value) == 12 ? "/[0-9]{2} [0-9]{4}-[0-9]{4}$/" : "^[0-9]{4}-[0-9]{4}$/^";
            }

            if(!preg_match($eregi, $this->_value)){
                $this->addErro();
            }
        }
    }

    /**
     * Verifica se um array possui valores
     * @param int $minValue
     */
   protected function arrayComValor($minValue = 1)
   {
      if(count($this->_value) < $minValue){
         $this->addErro();
      }
   }

    /**
     * Verifica se um valor j� n�o existe em um campo do banco de dados
     * @param Model $model
     * @param $field
     * @param null $fieldExcept
     * @param null $except
     */
   protected function uniqueInDb(Model $model, $field, $fieldExcept = null, $except = null)
   {
      if(!empty($this->_value)){
         $model->bindParam('value', $this->_value);
         $row = $model->where("{$field} = :value")->find();
            if(!empty($except)){
                if(!empty($row[$field]) && $row[$fieldExcept] != $except){
                    $this->addErro($this->_value);
                }
            }else{
                if(!empty($row[$field])){
                    $this->addErro($this->_value);
                }
            }
      }
   }

    /**
     * Verifica se um valor existe em um array
     * @param array $array
     */
   protected function inArray(array $array)
   {
      if(!empty($this->_value)){
         if(!in_array($this->_value, $array)){
            $this->addErro(implode(',', $array));
         }
      }
   }

   /**
    * Verifica se uma chave de valor existe em um array
    * @param array $array
    */
   protected function inKeyArray(array $array)
   {
      if(!empty($this->_value)){
         if(!array_key_exists($this->_value, $array)){
            $this->addErro(implode(',', $array));
         }
      }
   }

    /**
     * Verifica se as chaves de um array informado existem em um array
     * @param array $array
     */
   protected function arrayKeysIn(array $array)
   {
      if(is_array($this->_value)){
         foreach($this->_value as $key => $value){
            if(!in_array($key, $array)){
               $this->addErro(implode(',', $array));
            }
         }
      }
   }

    /**
     * Verifica se as chaves de um array informado n�o existem em um array
     * @param array $array
     */
    protected function arrayKeysNotIn(array $array)
    {
        if(is_array($this->_value)){
            foreach($this->_value as $key => $value){
                if(array_key_exists($key, $array)){
                    $this->addErro(implode(',', $array));
                }
            }
        }
    }

    /**
     * Verifica um valor � igual a outro valor informado
     * @param $value
     */
   protected function equalsTo($value)
   {
      if(!empty($this->_value) && $this->_value !== $value){
         $this->addErro($value);
      }
   }

    /**
    * Verifica se um valor � n�mero inteiro
    */
   protected function inteiro()
   {
      if(preg_match('/[^0-9]+/', $this->_value)){
         $this->addErro();
      }
   }

   /**
    * Verifica se um valor � maior que 0
    */
   protected function maiorZero()
   {
      if(strlen($this->_value) > 0) {
         if ($this->_value <= 0) {
            $this->addErro();
         }
      }
   }



   /**
    * Verifica se � um valor
    */
   protected function valor()
   {
      if(!empty($this->_value) && !is_numeric($this->_value)){
         $this->addErro();
      }
   }

    /**
     * Verifica se uma string � um permalink v�lido (sem acentos, espa�os, etc)
     */
   protected function permalink() 
   {
      if(preg_match('/[^a-z0-9\-]/', $this->_value)) {
         $this->addErro();
      }
   }

   /**
    * Verifica se uma string � uma url v�lida
    */
   protected function url()
   {
      if(!Zend_Uri::check($this->_value)){
         $this->addErro();
      }
   }

   /**
    * Verifica se uma determinada data � igual ou posterior a outra
    * @param $value
    * @param $field
    */
    protected function prazo($value, $field)
    {
        if(!empty($this->_value)){
            $dtInicio = str_replace('-', '', Esgn_Formata::dataDB($value));
            $dtFinal = str_replace('-', '', Esgn_Formata::dataDB($this->_value));

            if($dtFinal < $dtInicio){
                $this->addErro($field);
            }
        }
    }

   /**
    * Efetua callbacks para valida��es. Um callback deve ser utilizado quando a valida��o for especifica
    * @param array $callbacks
    */
   protected function callback($callbacks = array())
   {
      foreach($callbacks as $key => $callback){
         if(is_object($callback[0])){
            $class = $callback[0];
            $method = $callback[1];
            $params = $callback[2];
            
            $retorno = $class->$method($this->_value, $params);
            if(is_array($retorno) && $retorno['valido'] == false){
               $this->_valido = false;
               $this->_erros[$this->_id] = $retorno['mensagem'];
            }elseif(!$retorno){
               $this->_valido = false;
               $message = $this->_messages['cb_' . $method];
               $this->_erros[$this->_id] = $message;
            }
         }else{
            $function = $callback[0];
            $params = $callback[1];
            
            $retorno = $function($this->_value, $params);
            
            if(is_array($retorno) && $retorno['valido'] == false){
               $this->_valido = false;
               $this->_erros[$this->_id] = $retorno['mensagem'];
            }elseif(!$retorno){
               $this->_valido = false;
               $message = $this->_messages['cb_' . $function];
               $this->_erros[$this->_id] = $message;
            }
         }
      }
   }

   /**
    * Verifica se as dimensoes da imagem s�o v�lidas
    * @param $imagem
    * @param $w
    * @param $h
    */
    protected function dimensao($imagem, $w, $h)
    {
        if(!empty($imagem)){
            $imagem = getimagesize($imagem);
            if($imagem[0] != $w || $imagem[1] != $h){
                $this->addErro();
            }
        }
    }

   /**
    * Verifica se um valor existe em um campo do banco de dados
    * @param Model $model -> Esgn_Model para efetuar a query (deve ser uma instancia ou subclasse de Esgn_Model)
    * @param $field -> Nome do campo onde ser� feita a checagem
    * @param null $except
    */
   protected function existsInDb(Model $model, $field, $except = null)
   {
      if(!empty($this->_value)){
         $model->bindParam('value', $this->_value);
         $row = $model->where("{$field} = :value")->find();
         if(empty($row)){
            $this->addErro($this->_value);
         }
      }
   }

   public static function dataMesAno($data, $dia = '')//mes/ano
   {
      if(empty($dia)){
         $dia = '01';
      }

      if (!preg_match("/^[0-9]{2}/[0-9]{4}$/", $data)) {
         return false;
      } else {
         list($mes, $ano) = explode('/', $data);
         if (!checkdate($mes, $dia, $ano)) {
            return false;
         } else {
            return true;
         }
      }

   }


}
