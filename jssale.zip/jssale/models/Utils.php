<?php
namespace app\models;

use yii\db\ActiveRecord;
use yii\db\Query;
use Yii;
/**
 * Classe utilitária do BipCode
 */
class Utils {

    public static $_yes_no = array(0 => 'Não', 1 => 'Sim');

    public static $bc_types_id = array(
        'BIP_LINK' => 1,
        'BIP_MESSAGE' => 2,
        'BIP_GAME' => 3,
        'BIP_LOCAL' => 4,
        'BIP_CART' => 5,
        'BIP_PAYMENT' => 6,
        'BIP_GAME_CHILD' => 7,
        'BIP_TRANSFER' => 8,
        'BIP_ALERT' => 9,
        'BIP_NOTIFICATION' => 10,
        'BIP_IMAGE' => 11,
        'BIP_VIDEO' => 12,
        'BIP_REDIRECT' => 13,
        'BIP_CUPOM' => 14,
        'BIP_BUY' => 15
        );

    public static $bc_types_alias = array(
        1 => 'BIP LINK',
        2 => 'BIP MESSAGE',
        3 => 'BIP GAME',
        4 => 'BIP LOCAL',
        5 => 'BIP CART',
        6 => 'BIP PAYMENT',
        7 => 'BIP GAME CHILD',
        8 => 'BIP TRANSFER',
        9 => 'BIP ALERT',
        10 => 'BIP NOTIFICATION',
        11 => 'BIP IMAGE',
        12 => 'BIP VIDEO',
        13 => 'BIP REDIRECT',
        14 => 'BIP CUPOM',
        15 => 'BIP BUY'
    );

    public static $bip_url_base = "http://www.bipcode.com/";
    public static $bip_url_querystring = "b";



    /**
     * Retorna o tipo de BipCode
     * @param  integer $type [valor do tipo]
     * @return [String]        [alias do tipo]
     */
    public static function getQrType($type = 0) {

        if (isset(self::$bc_types_alias[$type])) {
            return self::$bc_types_alias[$type];
        } else {
            return '';
        }

    }

    public static function getExtensao($imagem){
        //retorna a extensao da imagem
        //return $extensao = strtolower(end(explode('.', $imagem)));
        $tmp = explode('.', $imagem);
        $file_extension = end($tmp);
        return $file_extension;
    }



    /**
     * Gerador de QRHash
     * Esse hash será o valor da querystring B na URL
     * @param  [int]   $user_id [ID do usuário criador e dono do QRCode]
     * @param  integer $prefix  [prefixo do HASH]
     * @return [String]         [QRHash gerado]
     */
    public static function genQrHash($user_id, $prefix = 0) {

        $user_id = str_pad($user_id, 8, '0', STR_PAD_LEFT);
        $qrhash = $prefix . date("YmdHis") . $user_id;

        return $qrhash;
    }



    /**
     * Gera a URL do Bip
     * Será usada para gerar QRCode
     * @param  [String] $hash [hash que representa o QrCode]
     * @return [String]       [URL gerada, pronta para ser codificada]
     */
    public static function genBipUrl($hash) {

        if (self::isNotNull($hash)) {

            $query_string = array(self::$bip_url_querystring => $hash);
            $url = self::$bip_url_base . '?' . http_build_query($query_string);

            return $url;

        } else {
            return false;
        }

    }



    /**
     * Verifica se uma String é nula ou vazia
     * @param  [String]  $str [String que será validada]
     * @return boolean        [description]
     */
    public static function isNull($str) {

        if (!isset($str) || empty($str) || $str == 'null' || $str == 'NULL' || $str == null) {
            return true;
        }

        return false;
    }



    /**
     * Verifica se uma String NÃO é nula ou vazia
     * @param  [type]  $str [description]
     * @return boolean      [description]
     */
    public static function isNotNull($str) {

        if (isset($str) && !empty($str) && $str != 'null' && $str != 'NULL' && $str != null) {
            return true;
        }

        return false;
    }



    /**
     * Retorna o valor nulo se não for preenchido
     * @param  [type] $value
     * @return [type]
     */
    public static function empty2null($value) {
        return $value === '' ? null : $value;
    }

    public static function dateTimeParser($date) {
        //$timezone = new DateTimeZone('America/Sao_Paulo');
        $dateObj = DateTime::createFromFormat('Y-m-d H:i:s', $date);
        return $dateObj->format('d/m/Y H:i:s');
    }


    /**
     * Verifica se o campo cont�m um cpf v�lido
     */
    public static function cpf($value)
    {
        if(!empty($value)){
            if(!preg_match("/^([0-9]{3}).([0-9]{3}).([0-9]{3})-([0-9]{2})/", $value)){
               return 1;
            }else{
                $value = str_replace ('.', '', $value);
                $value = str_replace ('-', '', $value);

                if(strlen($value) != 11){
                    return 1;
                }else{
                    $INS_cpf=preg_replace("/[^0-9]/","",$value);
                    $c=substr($value, 0,9);
                    $v=substr($value, 9,2);
                    $d=0;
                    $val=true;
                    for ($i=0;$i<9;$i++){
                        $d+=$c[$i]*(10-$i);
                    }
                    $d==0 ? $val=false:null;
                    $d= (11-($d%11))>9 ? 0:11-($d%11);
                    $v[0]!=$d ? $val=false:null;
                    $d *=2;
                    for ($i=0;$i<9;$i++){
                        $d+=$c[$i]*(11-$i);
                    }
                    $d= (11-($d%11))>9 ? 0:11-($d%11);
                    $v[1]!=$d ? $val=false:null;
                    preg_match("/0{11}|1{11}|2{11}|3{11}|4{11}|5{11}|6{11}|7{11}|8{11}|9{11}/",$INS_cpf) ? $val=false : null;
                    if(!$val){
                        return 1;
                    }
                    return 0;
                }
            }
        }
    }

    public static function formatTelToDb2($tel)
    {
        $rep = array("(", ")", " ", "-");
        $telefone = str_replace($rep, "", $tel);
        return !empty($telefone) ? $telefone : $tel;
    }

    /**
     * Formata data para DB
     * @param  [type] $date [description]
     * @return [type]       [description]
     */
    public static function formatDateToDb($datetime) {
        $date = DateTime::createFromFormat('d/m/Y', $datetime);
        return empty($date) ? $datetime : $date->format('Y-m-d');
    }

    /**
     * Formata datetime para DB
     * @param  [type] $datetime [description]
     * @return [type]       [description]
     */
    public static function formatDateTimeToDb($datetime) {
        $date = DateTime::createFromFormat('d/m/Y H:i:s', $datetime);
        return empty($date) ? $datetime : $date->format('Y-m-d H:i:s');
    }

    public static function formatDateSemHr($datetime) {
        $date = DateTime::createFromFormat('Y-m-d H:i:s', $datetime);
        return empty($date) ? $datetime : $date->format('d/m/Y');
    }

    /**
     * Formata Datetime para View
     * @param  [type] $datetime [description]
     * @return [type]           [description]
     */
    public static function formatDateTimeToView($datetime) {
        $date = DateTime::createFromFormat('Y-m-d H:i:s', $datetime);
        return empty($date) ? $datetime : $date->format('H:i:s d/m/Y');
    }

    /**
     * Retorna apenas a data para View
     * @param  [type] $datetime [DATETIME do Mysql]
     * @return [type]           [description]
     */
    public static function formatOnlyDateToView($datetime) {
        $date = DateTime::createFromFormat('Y-m-d', $datetime);
        return empty($date) ? $datetime : $date->format('d/m/Y');
    }

    /**
     * Formata Datetime para View
     * @param  [type] $datetime [description]
     * @return [type]           [description]
     */
    public static function formatDateTimeToDateInput($datetime) {
        $tmp = strtotime($datetime);
        return date('d/m/Y H:i:s', $tmp);
    }

    /**
     * Formata a data para View
     * @param  [type] $date [description]
     * @return [type]       [description]
     */
    public static function formatDateToView($date) {
        $tmp = strtotime($date);
        return date('d/m/Y', $tmp);
    }

    public static function formatDateToDBb($date) {
        $tmp = explode("/", $date);
        $mt = $tmp[2] . '/' . $tmp[1] .  '/' .$tmp[0];
        return  $mt;
    }

    public static function formatDateToDBb2($date) {
        $tmp = explode("/", $date);
        $mt = $tmp[2] . '-' . $tmp[1] .  '-' .$tmp[0];
        return  $mt;
    }

    public static function sobrenome($valor)
    {
        $value = explode(" ", $valor);
        $cc = count($value);
        if($cc < 1){

            return false;
        }

        if(strlen($value[0]) < 1){

            return false;
        }

        if(strlen($value[1]) < 1){

            return false;
        }
        return true;
    }

    public static function getRegiao($key)
    {

        $regiao = array(
            'Sul' => 2,
            'Sudeste' => 1,
            'Centro-Oeste' => 3,
            'Nordeste' => 4,
            'Norte' => 5,
        );

        return $regiao[$key];
    }


    function returnMKTime($year, $month, $days) {

        $startTime = mktime(0, 0, 0, $month, $days, $year);
        return  $startTime;
    }

    /**
     * Parser to Datetime
     * @param  [type] $datetime [Date/Hour]
     * @param  [type] $input    [Format input]
     * @param  [type] $output   [Format output]
     * @return [type]           [description]
     */
    public static function dateParser($datetime, $input, $output) {
        $date = DateTime::createFromFormat($input, $datetime);
        return empty($date) ? $datetime : $date->format($output);
    }

    /**
     * Verifica se um campo cont�m um n�mero de telefone v�lido
     */
    public static function telefone($value)
    {
        if(!empty($value)){
            if(strlen($value) == 15){
                $eregi = "/^11|12|13|14|15|16|17|18|19|21|22|24|27|29 9(5[0-9]|6[0-9]|7[01234569]|8[0-9]|9[0-9])[0-9]{1}[0-9]-[0-9]{4}$^/";
            }else{
                $eregi = strlen($value) == 11 ? "/^11|12|13|14|15|16|17|18|19|21|22|24|27|29 9(5[0-9]|6[0-9]|7[01234569]|8[0-9]|9[0-9])[0-9]{1}[0-9]-[0-9]{4}$^/" : "^[0-9]{4}-[0-9]{4}$/^";

            }

            if(!preg_match($eregi, $value)){
                return 1;
            }else{
                return 0;
            }
        }
    }



    /**
     * Converte a data para timestamp
     * Para os gráficos
     * @param  [type] $date [description]
     * @return [type]       [description]
     */
    public static function dateToChart($date) {
        return (strtotime($date)) * 1000;
    }



    /**
     * Formata Telefone para formato do banco
     * @return [type] [description]
     */
    public static function formatPhoneToDb($phone) {
        return str_replace(array("(",")","-","+","."," "), "", $phone);
    }

    public static function formatCeptoDb($dado) {
        return str_replace(array("(",")","-","+","."," "), "", $dado);
    }

    public static function formatTeltoDb($dado) {
        return str_replace(array("(",")","-","(","."," ",")"), "", $dado);
    }


    /**
     * Formata Telefone para formato da interface
     * @return [type] [description]
     */
    public static function formatPhoneToView($phone) {
        $ddd = substr($phone, 0, 2);
        $tel1 = substr($phone, 2, 4);
        $tel2 = substr($phone, 4, 4);
        return "(".$ddd.")".$tel1."-".$tel2;
    }



    /**
     * Retorna o CONTENT do Game
     * @param  [type] $game_id [description]
     * @return [type]          [description]
     */
    public static function getGameContent($game_id) {
        $model = new App_Games;
        $game = $model->findByPk($game_id);

        $json = array();
        $json['id'] = $game_id;
        $json['name'] = $game->name;
        $json['tpl'] = $game->qrcode_alignment;

        return json_encode($json);
    }


    /**
     * Retorna a idade do usuário
     * @param  [type] $birthday [description]
     * @return [type]           [description]
     */
    public static function getUserAge($birthday) {

        $from = new DateTime($birthday);
        $to   = new DateTime('today');

        return $from->diff($to)->y;
    }



    /**
     * Gera um RGB randomico
     * @param  [type] $string [description]
     * @return [type]         [description]
     */
    public static function randColor($string) {

        /*define( COL_MIN_AVG, 64 );
        define( COL_MAX_AVG, 192 );
        define( COL_STEP, 16 );*/

        $range = 192 - 64;
        $factor = $range / 256;
        $offset = 64;

        $base_hash = substr(md5($string), 0, 6);
        $b_R = hexdec(substr($base_hash,0,2));
        $b_G = hexdec(substr($base_hash,2,2));
        $b_B = hexdec(substr($base_hash,4,2));

        $f_R = floor((floor($b_R * $factor) + $offset) / 16) * 16;
        $f_G = floor((floor($b_G * $factor) + $offset) / 16) * 16;
        $f_B = floor((floor($b_B * $factor) + $offset) / 16) * 16;

        return sprintf('#%02x%02x%02x', $f_R, $f_G, $f_B);
    }



    public static function slugify($text) {

        // replace non letter or digits by -
        $text = preg_replace('~[^\\pL\d]+~u', '-', $text);

        // trim
        $text = trim($text, '-');

        // transliterate
        if (function_exists('iconv'))
        {
            $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
        }

        // lowercase
        $text = strtolower($text);

        // remove unwanted characters
        $text = preg_replace('~[^-\w]+~', '', $text);

        if (empty($text))
        {
            return 'n-a';
        }

        return $text;
    }



    /**
     * Seta os valores do JSON nos atributos corretos do Model
     * @param [type] $model [Model em questão]
     * @param [type] $json  [JSON]
     */
    public static function setJsonToAttributes($model, $json) {

        $json = json_decode($json);

        // Se o Decode for NULL converte em JSON
        if (empty($json)) {
            $json = json_decode(json_encode($json));
        }

        foreach ($json as $key => $value) {
            if (property_exists($model, $key))
                $model->$key = $value;
        }

    }


    /**
     * Retorna uma senha
     * @return [type] [description]
     */
    public static function randomPassword() {
        $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
        $pass = array(); //remember to declare $pass as an array
        $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
        for ($i = 0; $i < 8; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); //turn the array into a string
    }

    public static function returnTime ($year, $month, $days) {

        $startTime = mktime(0, 0, 0, $month, $days, $year);
        return  $startTime;
    }

    public static function multiexplode ($delimiters,$string) {

        $ready = str_replace($delimiters, $delimiters[0], $string);
        $launch = explode($delimiters[0], $ready);
        return  $launch;
    }

    /**
     * Truncate email
     * @param  [type] $email [description]
     * @return [type]        [description]
     */
    public static function truncateEmail($email) {

        if (!filter_var($email, FILTER_VALIDATE_EMAIL))
            return 'E-mail inválido, solicite um novo para o cliente';

        $email = explode('@', $email);
        return preg_replace('/./', '*', $email[0]) . '@' . $email[1];
    }


    /**
     * Format Price to view
     * @param  [type] $value [description]
     * @return [type]        [description]
     */
    public static function formatPrice($value) {
        return $value;
        setlocale(LC_MONETARY, 'pt_BR.UTF-8');
        return money_format('%.2n', $value);
    }

    /**
     * Formata data para banco dedados mysql
     */
    public static function dataDb($value)
    {
        $dtNascimentoArr = explode("/", $value);
        $dtNascDB = $dtNascimentoArr[2] . '-' . $dtNascimentoArr[1] . '-' . $dtNascimentoArr[0];
        return $dtNascDB;
    }

    /**
     * Formata data para banco dedados mysql
     */
    public static function dataDb2($value)
    {
        $dtNascimentoArr = explode("/", $value);
        $count = count($dtNascimentoArr);
        if($count == 3){
            $dtNascDB = $dtNascimentoArr[2] . '-' . $dtNascimentoArr[1] . '-' . $dtNascimentoArr[0];
            return $dtNascDB;
        }else{
            return false;
        }

    }

    /**
     * Formata data para banco dedados mysql
     */
    public static function data($value)
    {
        $dtNascimentoArr = explode("-", $value);
        $dtNasc = $dtNascimentoArr[2] . '/' . $dtNascimentoArr[1] . '/' . $dtNascimentoArr[0];
        return $dtNasc;
    }

    /**
     * Formata data para banco dedados mysql
     */
    public static function formatValor($value)
    {
        $fmVlor = str_replace('.', ',' , $value);
        return $fmVlor;
    }


    /**
     * Formata data para banco dedados mysql
     */
    public static function statusAzPay($key)
    {
        $array = array(
            '1' => 'Pendente',
            '2' => 'Aguardando Pagamento',
            '3' => 'Aprovada',
            '4' => 'Negado',
            '5' => 'Cancelada',
            '6' => 'Desfeita',
            '7' => 'Aguardando Aprovação do Vendedor',
            '8' => 'Cancelando',
            '9' => 'Capturando',
            '10' => 'Não Capturado',
            '11' => 'Expirado',
            '12' => 'Negado 3 tentativas'
        );

        return array_key_exists($key, $array) ? $array[$key] : $array;
    }

    /**
     * Filtros
     */
    public static function filtrosOrdem($key = array())
    {

        $where = '';
        foreach($key as $k => $filtro){
            $array = array(
                'name' => " AND webbuy_users.name LIKE '%{$key['name']}%'",
                'email' => " AND webbuy_users.email LIKE '{$key['email']}%'",
                'doc' => " AND webbuy_users.doc = '{$key['doc']}'",
                'date_create' => "AND webbuy_transactions.date_create >= '{$key['date_create']}'",
                'phone' => "AND webbuy_users.phone = '{$key['phone']}'",
            );

          $where .= array_key_exists($k, $array) && !empty($filtro) ? $array[$k] : '';
        }
        return $where;

        //return array_key_exists($key, $array) && !empty($filtro) ? $array[$key] : $array;
    }


    /**
     * Format Data to View
     * @param  [type] $date [description]
     * @return [type]       [description]
     */
    public static function formatDate($date) {
        $timezone = new DateTimeZone('America/Sao_Paulo');
        $dateObj = DateTime::createFromFormat('Y-m-d H:i:s', $date, $timezone);
        return $dateObj->format('d/m/Y H:i:s');
    }

    public static function clasBox($key)
    {
        $array = array(
            '1' => 'box-primary',
            '2' => 'box-success',
            '3' => 'box-warning',
            '4' => 'box-danger'
        );

        return array_key_exists($key, $array) ? $array[$key] : $array;
    }


    /**
     * Class by Status
     * @param  [type] $status [description]
     * @return [type]         [description]
     */
    public static function transactionStatusClass($status) {

        switch ($status) {
            case 1:
                return 'info';
            case 2:
                return 'warning';
            case 3:
                return 'success';
            case 4:
            case 5:
            case 6:
                return 'danger';
            default:
                return 'primary';
        }
    }


    /**
     * Set Header response
     * @param [type] $code [description]
     */
    public static function setHeader($code) {

        // For 4.3.0 <= PHP <= 5.4.0
        if (!function_exists('http_response_code')) {
            header('X-PHP-Response-Code: '.$code, true, $code);
        } else {
            http_response_code($code);
        }

        if ($code >= 500)
            exit();
    }


    /**
     * UUID v4
     * @return [type] [description]
     */
    public static function uuidv4() {

        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',

        // 32 bits for "time_low"
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),

        // 16 bits for "time_mid"
        mt_rand(0, 0xffff),

        // 16 bits for "time_hi_and_version",
        // four most significant bits holds version number 4
        mt_rand(0, 0x0fff) | 0x4000,

        // 16 bits, 8 bits for "clk_seq_hi_res",
        // 8 bits for "clk_seq_low",
        // two most significant bits holds zero and one for variant DCE1.1
        mt_rand(0, 0x3fff) | 0x8000,

        // 48 bits for "node"
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }


    /**
     * LogPush Sent
     * @param  [type] $flag    [description]
     * @param  [type] $sender_id [description]
     * @param  [type] $gcm_id  [description]
     * @param  [type] $payload [description]
     * @return [type]          [description]
     */
    public static function logPushSent($flag, $sender_id, $gcm_id, $payload) {

        $sent = new PushSent();
        $sent->flag = $flag;
        $sent->user_id = $sender_id;
        $sent->gcm_id = $gcm_id;
        $sent->payload = is_array($payload) || is_object($payload) ? json_encode($payload) : $payload;
        $sent->datetime = date('Y-m-d H:i:s');

        if (!$sent->save()) {
            Yii::app()->yiiSimpleSlack->sendMessage('[PUSH_SENT] ' . json_encode($sent->getErrors()));
            return false;
        } else {
            return $sent->getPrimaryKey();
        }

    }

    /**
     * Log Push response
     * @param  [type] $user_id [description]
     * @param  [type] $push    [description]
     * @return [type]          [description]
     */
    public static function logPushResponse($sent_id, $user_id, $push, $android = false) {
        
        // If is Android, check Canical, to prevent block
        if ($android)
            self::gcmCanonical($user_id, $push);

        $response = new PushResponse();
        $response->push_sent_id = $sent_id;
        $response->response = (is_object($push) || is_array($push)) ? json_encode($push) : $push;
        if (!$response->save())
            Yii::app()->yiiSimpleSlack->sendMessage('[PUSH_RESPONSE] ' . json_encode($response->getErrors()));
    }


    /**
     * Set header for AJAX request
     * return JSON
     */
    public static function setAJAXHeader() {

        foreach (Yii::app()->log->routes as $route) {
            $route->enabled=false;
        }

        header('Content-type: application/json');
    }


    /**
     * Update canonical registrations
     * @param  [type] $user_id  [description]
     * @param  [type] $response [description]
     * @return [type]           [description]
     */
    public static function gcmCanonical($user_id, $response) {
        $response = json_decode($response);

        // Update registration ID
        if ($response->canonical_ids != 0) {

            foreach ($response->results as $key => $value) {

                $gcm = Gcm::model()->findByAttributes(array('users_user_id'=>$user_id), array('order'=>'id DESC'));
                if (!empty($gcm)) {
                    $gcm->registration = $value->registration_id;
                    if (!$gcm->saveAttributes(array('registration')))
                        Yii::app()->yiiSimpleSlack->sendMessage('[PUSH_CANONICAL] ' . json_encode($gcm->getErrors()));
                }

            }

        }

    }


    /**
     * Export CSV
     * @return [type] [description]
     */
    public static function exportCSV($data, $filename = null) {

        Yii::import('ext.ECSVExport');

        $csv = new ECSVExport($data);
        $content = $csv->toCSV();

        if (empty($filename)) {

            return file_get_contents($content);

        } else {

            Yii::app()->getRequest()->sendFile($filename, $content, "text/csv", false);
            exit();
        }

    }


    /**
     * Get Client IP
     * @return [type] [description]
     */
    public static function getClientIP() {
        $ipaddress = '';

        if (isset($_SERVER['HTTP_CLIENT_IP']) && !empty($_SERVER['HTTP_CLIENT_IP']))
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']) && !empty($_SERVER['HTTP_X_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_X_FORWARDED']) && !empty($_SERVER['HTTP_X_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        else if(isset($_SERVER['HTTP_FORWARDED_FOR']) && !empty($_SERVER['HTTP_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_FORWARDED']) && !empty($_SERVER['HTTP_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        else if(isset($_SERVER['REMOTE_ADDR']) && !empty($_SERVER['REMOTE_ADDR']))
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        else
            $ipaddress = 'UNKNOWN';

        return $ipaddress;
    }


    /**
     * Check keys exists in array
     * @param  [type]  $array [description]
     * @param  [type]  $keys  [description]
     * @return boolean        [description]
     */
    public static function hasInArray($array, $keys) {

        if (!is_array($array))
            return false;

        if (!is_array($keys)) {

            return isset($array[$keys]) && !empty($array[$keys]);

        } else {

            foreach ($keys as $key => $value) {

                if (!isset($array[$value]) || empty($array[$value]))
                    return false;
            }

        }

        return true;

    }


    /**
     * Return only Capital letters
     * @param  [type] $input [description]
     * @return [type]        [description]
     */
    public static function onlyCapital($input) {

        $capitals = '';

        preg_match('/^[A-Z]+/', $input, $matches);

        foreach ($matches as $key => $value) {
            $capitals .= $value;
        }

        return $capitals;
    }


    /**
     * Hours remaining
     * @param  [type] $time [description]
     * @return [type]       [description]
     */
    public static function timeRemaining($time) {

        $now = new DateTime();
        $future_date = new DateTime($time);

        if ($now >= $future_date)
            return Yii::t('app', 'Finished');

        $interval = $future_date->diff($now);
        return $interval->format("%dd %H:%I:%S");
    }


    /**
     * [parseModelErrors description]
     * @param  [type] $model [description]
     * @return [type]        [description]
     */
    public static function parseModelErrors($model) {

        $message = '';
        if(!is_array($model))
            $model=array($model);

        foreach($model as $m) {
            foreach($m->getErrors() as $errors) {
                foreach($errors as $error) {
                    if($error!='')
                        $message .= $error;
                }
            }
        }

        return $message;
    }


    /**
     * Admin Languages
     * @param  [type] $id [description]
     * @return [type]     [description]
     */
    public static function getLanguages($id = null) {
        $lang = [
            'en' => 'English',
            'pt-BR' => 'Português',
        ];
        return ($id !== null) ? $lang[$id] : $lang;
    }


    /**
     * Check if strings Starts With
     * @param  [type] $haystack [description]
     * @param  [type] $needle   [description]
     * @return [type]           [description]
     */
    public static function startsWith($haystack, $needle){
        return strncmp($haystack, $needle, strlen($needle)) === 0;
    }

    /**
     * Check if strings Ends With
     * @param  [type] $haystack [description]
     * @param  [type] $needle   [description]
     * @return [type]           [description]
     */
    public static function endsWith($haystack, $needle) {
        return $needle === '' || substr_compare($haystack, $needle, -strlen($needle)) === 0;
    }


    public static function pushException($flag, Exception $exception) {
        Yii::app()->yiiSimpleSlack->sendMessage('['.$flag.'] ' . $exception->getCode() . ': ' . $exception->getMessage() . ' | user: '.Yii::app()->user->id . ' | business: '.Yii::app()->session['businessActive']);
    }

    public static function pushError($flag, $error) {
        Yii::app()->yiiSimpleSlack->sendMessage('['.$flag.'] ' . $error . ' | user: '.Yii::app()->user->id . ' | business: '.Yii::app()->session['businessActive']);
    }

    /**
     * Validate Username
     * @param  [type] $username [description]
     * @return [type]           [description]
     */
    public static function validateUsername($username) {
        return preg_match('/(^\.|\.$)/', $username) !== 1 && preg_match('/^[a-zA-Z0-9_.]{3,15}$/', $username) === 1;
        //return preg_match('/^\w{3,15}$/', $username) === 1;
    }

    /**
     * [menuActiveByPage description]
     * @param  [type] $path [description]
     * @return [type]       [description]
     */
    public static function menuActiveByPage($path) {
        return (preg_match('/' . trim(str_replace('/', '\/', $path)) . '/', $_SERVER['REQUEST_URI']) == 1) ? 'active' : null;
    }

}