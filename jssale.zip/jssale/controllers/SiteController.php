<?php

namespace app\controllers;

use app\models\Cadastro;
use app\models\Regiao;
use app\models\Unidade;
use app\models\Utils;
use app\models\Validacao;
use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;

class SiteController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        //Instancias
        $mdlRegiao = new Regiao();
        $arrRegiao = $mdlRegiao->getRegiao();


        $this->view->params['regioes'] = $arrRegiao;
        return $this->render('index');
    }

    public function actionUnidade()
    {

        $this->layout = false;
        //Instancias
        $mdlUnidade = new Unidade();

        $id = Yii::$app->request->post();
        $arrUnidade = $mdlUnidade->getUnidadeByIdRegiao($id['id']);
        $this->view->params['unidades'] = $arrUnidade;
        return $this->render('unidade');
    }

    public function actionAjaxsalvar()
    {
        $this->layout = false;
        //Instancias
        $mdlCadastro = new Cadastro();
        $dados = Yii::$app->request->post();
        $erros = '';
        $validacao = $this->valida($dados);

        $retorno = false;
        if($validacao->validar()) {
            $nmpalavras = Utils::sobrenome($dados['nome']);
            if($nmpalavras){
                $score = $mdlCadastro->calcularScore($dados);
                $retorno = $mdlCadastro->adicionar($dados, $score);
            }else{
                $erros['nome'] = 'O campo deve conter ao menos 2 palavras';
            }

        }else{
            $erros =  $validacao->getErros();

        }

        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;;
        if($retorno){
            return array('resultado' =>  true, 'erro' => 'n', 'score' => $score, 'dtnasc' => Utils::formatDateToDBb2($dados['dtnascimento']));

        }else{
            return array('resultado' =>  false, 'erro' => $erros);
        }


    }

    //config de validacao
    public function valida($dados)
    {
        $config = array(
            'nome' => array(
                'label' => 'Nome',
                'value' => $dados['nome'],
                'rules' => array('obrigatorio'),
                'messages' => 'O campo e obrigatorio'
            ),
            'email' => array(
                'label' => 'Email',
                'value' => $dados['email'],
                'rules' => array('email', 'obrigatorio'),
                'messages' => 'O campo e obrigatorio'
            ),
            'telefone' => array(
                'label' => 'Telefone',
                'value' => $dados['telefone'],
                'rules' => array('telefone'),
                'messages' => 'O campo e obrigatorio'
            ),
            'id' => array(
                'label' => 'Unidade',
                'value' => $dados['id'],
                'rules' => array('obrigatorio'),
                'messages' => 'O campo e obrigatorio'
            ),
            'dtnascimento' => array(
                'label' => 'Data de Nascimento',
                'value' => $dados['dtnascimento'],
                'rules' => array('obrigatorio', 'data'),
                'messages' => 'O campo e obrigatorio'
            ),
        );

        if($dados['regiao'] == 'Norte'){
            unset($config['id']);

        }

        return new Validacao($config);
    }

    /**
     * Login action.
     *
     * @return string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return string
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    /**
     * Displays contact page.
     *
     * @return string
     */
    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    /**
     * Displays about page.
     *
     * @return string
     */
    public function actionAbout()
    {
        return $this->render('about');
    }
}
