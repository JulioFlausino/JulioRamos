<option value="">Selecione a unidade mais próxima</option>
<?php if(!empty($this->params['unidades'])){ ?>

    <?php foreach($this->params['unidades'] as $k => $unidade){ ?>
        <option value="<?php echo $unidade['id'] ?>"><?php echo $unidade['nmunidade']; ?></option>
    <?php } ?>
<?php }else{ ?>
    <option value="">Não possui disponibilidade</option>
<?php } ?>