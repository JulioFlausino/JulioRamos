<style>
    .modal2 {
        display:    none;
        position:   fixed;
        z-index:    1000;
        top:        0;
        left:       0;
        height:     100%;
        width:      100%;
        background: rgba( 255, 255, 255, .8 )
        url('http://i.stack.imgur.com/FhHRx.gif')
        50% 50%
        no-repeat;
    }

    body.loading {
        overflow: hidden;
    }

    body.loading .modal2 {
        display: block;
    }
</style>
<div class="container">
    <div class="row" style="margin:30px 0">
        <div class="col-lg-3">
            <img src="<?php echo Yii::$app->getUrlManager()->getBaseUrl() . '/public/img/logo.png'; ?>" class="img-thumbnail">
        </div>
        <div class="col-lg-9">
            <h3>Nome do Produto</h3>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6" id="form-container">

            <form id="step_1" class="form-step">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <div class="panel-title">
                            Preencha seus dados para receber contato
                        </div>
                    </div>
                    <div class="panel-body">
                        <fieldset>
                            <div class="row form-group">
                                <div class="col-lg-6">
                                    <label>Nome Completo</label>
                                    <input class="form-control" id="nome" type="text" name="nome">
                                </div>

                                <div class="col-lg-6">
                                    <label>Data de Nascimento</label>
                                    <input class="form-control date" id="dtnascimento" type="text" name="data_nascimento">
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col-lg-6">
                                    <label>Email</label>
                                    <input class="form-control" id="email" type="text" name="email">
                                </div>

                                <div class="col-lg-6">
                                    <label>Telefone</label>
                                    <input class="form-control phone" id="telefone" type="text" name="telefone">
                                </div>
                            </div>

                            <div>
                                <button type="submit" class="btn btn-lg btn-info next-step">Próximo Passo</button>
                            </div>
                        </fieldset>
                    </div>
                </div>
            </form>

            <form id="step_2" class="form-step" style="display:none">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <div class="panel-title">
                            Preencha seus dados para receber contato
                        </div>
                    </div>
                    <div class="panel-body">
                        <fieldset>
                            <div class="row form-group">
                                <div class="col-lg-6">
                                    <label>Região</label>
                                    <select class="form-control regiao" name="regiao">
                                        <option value="">Selecione a sua região</option>
                                        <?php foreach($this->params['regioes'] as $k => $regiao){ ?>
                                        <option value="<?php echo $regiao['id']; ?>" ><?php echo $regiao['nmregiao']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>

                                <div class="col-lg-6">
                                    <label>Unidade</label>
                                    <select class="form-control unidade" name="unidade">
                                        <option value="">Selecione a unidade mais próxima</option>
                                    </select>
                                </div>
                            </div>

                            <div>
                                <button type="submit" class="btn btn-lg btn-info next-step salvar">Enviar</button>
                            </div>
                        </fieldset>
                    </div>
                </div>
            </form>

            <div id="step_sucesso" class="form-step" style="display:none">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <div class="panel-title">
                            Obrigado pelo cadastro!
                        </div>
                    </div>
                    <div class="panel-body">
                        Em breve você receberá uma ligação com mais informações!
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <h1>Chamada interessante para o produto</h1>
            <h2>Mais uma informação relevante</h2>
        </div>
    </div>
</div>
<div class="modal2  "><!-- Place at bottom of page --></div>
<script>
    $(function () {
        $('.next-step').click(function (event) {
            event.preventDefault();
            $(this).parents('.form-step').hide().next().show();
        });
    });
    $body = $("body");

    //mascaras
    $('.date').mask('00/00/0000');
    $('.phone').mask('(00) 0000-00000');
    //--
    $( ".regiao" ).change(function() {
       var id = $( ".regiao" ).val();
      getUnidades(id);
    });

    function getUnidades(id)
    {
        $.ajax({
            url: '<?php echo Yii::$app->request->baseUrl. '/site/unidade' ?>',
            type: 'post',
            dataType:"HTML",
            data: {id: id,_csrf : '<?=Yii::$app->request->getCsrfToken()?>'},
            success: function (data) {
                $('.unidade').empty().append("<option value=''>Selecione a unidade mais próxima</option>");
                $('.unidade').html(data);
            }

        });

    }

    $( ".salvar" ).click(function() {
        var id = $( ".unidade" ).val();
        var nome = $('#nome').val();
        var email = $("#email").val();
        var telefone = $("#telefone").val();
        var dtnascimento = $('#dtnascimento').val();
        var nmregiao = $( ".regiao option:selected" ).text();
        var nmunidade = $( ".unidade option:selected" ).text();
        salvar(id, nome, email, dtnascimento, telefone, nmregiao, nmunidade);

    });

    function salvar(id, nome, email,dtnascimento,telefone, nmregiao, nmunidade){

        swal({
            title: 'Deseja Salvar ?',
            text: "",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Salvar',
            cancelButtonText: 'Cancelar',
            confirmButtonClass: 'btn btn-success',
            cancelButtonClass: 'btn btn-danger',
            buttonsStyling: false
        }).then(function () {
            ajaxStart: $body.addClass("loading");
            $.ajax({
                url: '<?php echo Yii::$app->request->baseUrl. '/site/ajaxsalvar' ?>',
                type: 'post',
                data: {id: id , nome: nome,email: email,regiao: nmregiao,unidade: nmunidade ,dtnascimento: dtnascimento,telefone: telefone,_csrf : '<?=Yii::$app->request->getCsrfToken()?>'},
                success: function (data) {
                    ajaxStart: $body.removeClass("loading");
                    if(data.erro == 'n'){
                        swal(
                            'Salvo!',
                            'Os dados foram salvos com sucesso',
                            'success'
                        )
                        mandarApi(id, nome, email,data.dtnasc,telefone, data.score);
                    }else{
                        var erromensagem  = '';
                        $.each(data.erro, function (i, item) {
                            erromensagem += item;
                        });
                        swal(
                            'Os dados não foram salvos!',
                            "'" + erromensagem +"'",
                            'error'
                        )
                        setTimeout(function(){ window.location = ""; }, 3000);
                       // window.location = "";
                    }
                }
            });
        }, function (dismiss) {
            ajaxStart: $body.removeClass("loading");
            if (dismiss === 'cancel') {
                swal(
                    'Cancelado',
                    'Nenhum dado foi salvo',
                    'error'
                )
            }
        })
    }

    function mandarApi(id, nome, email,dtnascimento,telefone, score){
        var nmregiao = $( ".regiao option:selected" ).text();
        var nmunidade = $( ".unidade option:selected" ).text();
        if(nmregiao == 'Norte'){
            nmunidade = 'INDISPONÍVEL';
        }


        var token = "855faf9a3a0e73f202e2c8b7b6c2aef8";
        $.ajax({
            url: 'http://api.actualsales.com.br/join-asbr/ti/lead',
            type: 'post',
            data: {nome: nome,email: email,data_nascimento: dtnascimento,regiao: nmregiao, unidade: nmunidade,score:score , telefone: telefone, token:token},
            success: function (data) {
                console.log(data);
            }
        });

    }

</script>