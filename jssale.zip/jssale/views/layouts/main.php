<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compre Já</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="<?php echo Yii::$app->getUrlManager()->getBaseUrl() . '/js/jquery.mask.min.js'; ?>"></script>
    <script src="<?php echo Yii::$app->getUrlManager()->getBaseUrl() ?>/css/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="<?php echo Yii::$app->getUrlManager()->getBaseUrl() ?>/css/sweetalert2.min.css">
</head>

<body>
<?php $this->beginBody() ?>


<?= $content ?>


<footer class="footer">
    <div class="container">
        <p class="pull-left">&copy; Julio Ramos <?= date('Y') ?> </p>

        <p class="pull-right">julio_davids_89@hotmail.com</p>
    </div>
</footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
